﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PNotas
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            char[,] respostaAlunos = new char[1, 10];
            char[] respostaCorretas = new char[10] { 'A', 'B', 'C', 'D', 'E', 'A', 'B', 'C', 'D', 'E' };
            string auxiliar;
            int l, c;


            //RESPOSTA DOS ALUNOS
            for (l = 0; l < 1; l++) //aluno
            {
                for (c = 0; c < 10; c++) //respostas
                {
                    
                    auxiliar = Interaction.InputBox("Digite as respostas", "Entrada de dados");
                    auxiliar = auxiliar.ToUpper();
                    if (!char.TryParse(auxiliar, out respostaAlunos[l, c]))
                    {
                        MessageBox.Show("Erro! Digite um valor válido! ");
                        c--;
                    }
                    
                    else
                    {
                        if ((respostaAlunos[l, c] == 'A') || (respostaAlunos[l, c] == 'B') || (respostaAlunos[l, c] == 'C' || (respostaAlunos[l, c] == 'D') || (respostaAlunos[l, c] == 'E')))
                        {
                        if (respostaCorretas[c] == respostaAlunos[l, c])
                        {
                            lstBoxResultados.Items.Add("O aluno " + (l + 1) + " acertou a questão " + (c + 1) + " era " + respostaCorretas[c] + " mas escolheu " + respostaAlunos[l, c]);
                        }
                        else
                        {
                            lstBoxResultados.Items.Add("O aluno " + (l + 1) + " ERROU a questão " + (c + 1) + " era " + respostaCorretas[c] + " mas escolheu " + respostaAlunos[l, c]);
                        }
                        }
                        else
                        {
                            MessageBox.Show("Erro! Digite um valor válido! ");
                            c--;
                        }
                    }

                }

            }

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstBoxResultados.Items.Clear();
        }

    }
}


